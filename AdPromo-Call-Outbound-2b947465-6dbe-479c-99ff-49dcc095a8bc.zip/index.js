const AWS = require('aws-sdk');
AWS.config.update({ region: 'us-east-1' });

exports.handler = (event, context, callback) => {
    let connect = new AWS.Connect();
    
    const customerName = event.name;
    const customerPhoneNumber = event.number;
    const dayOfWeek = event.day;
    
    let params = {
        "InstanceId" : '298c8642-3d37-489f-bf85-cfb2c354c4b8',
        "ContactFlowId" : 'fae8fab1-014e-44cf-927c-a2d55ae22b22',
        "SourcePhoneNumber" : '+18888888888',
        "DestinationPhoneNumber" : customerPhoneNumber,
        "Attributes" : {
            'name' : customerName,
            'dayOfWeek' : dayOfWeek
        }
        
    }
    
    connect.startOutboundVoiceContact(
        params, function (error, response){
            
            if(error) {
                console.log(error)
                callback("Error", null);
            } else
            {
                console.log('Initiated an outbound call with Contact Id ' + JSON.stringify(response.ContactId));
                callback(null, 'Success');
            }
        }
        );

    
};

