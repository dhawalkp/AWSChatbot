const AWS = require('aws-sdk');
AWS.config.update({ region: 'us-east-1' });

exports.handler = async (event,context,callback) => {
    
     var response;
    
    console.log(event);
    
    if ('AdPromo' == event.currentIntent.name) {
        
        console.log("Processing AddPromo Intent");
        response =  {
      "dialogAction": {
            "type": "Close",
            "fulfillmentState": "Fulfilled",
                 "message": {
                    "contentType": "PlainText",
                    "content": "We have 30% discount promo going on in the City"
                    }
        }
        
    };
    }
    else if ('ConnectToAgent' == event.currentIntent.name) {
        console.log("Processing ConnectToAgent Intent");
        
        if (event.sessionAttributes && event.sessionAttributes.XChannel && 'VOICE' == event.sessionAttributes.XChannel ) {
            
            response =  {
      "dialogAction": {
            "type": "Close",
            "fulfillmentState": "Fulfilled",
                 "message": {
                    "contentType": "PlainText",
                    "content": "ok!. Connecting you to an agent..please hold!"
                    }
        }
        
    };
            
        }
        else
        {
        response =  {
      "dialogAction": {
          "type": "Close",
          "fulfillmentState": "Fulfilled",
          "message": {
            "contentType": "PlainText",
            "content": "Thanks! We will connect you with our Service Center now! Please accept the Call on your Phone!"
            }
            
          /*responseCard: {
            "version": 1,
            "contentType": "application/vnd.amazonaws.card.generic",
                    "genericAttachments": [
                        {   
                            "title": "Click-To-Call",
                            "imageUrl": "https://www.ivr.com.sg/wp-content/uploads/2013/06/43.png",
                            "attachmentLinkUrl": "https://www.ivr.com.sg/wp-content/uploads/2013/06/43.png",
                            "buttons": [
                                    {
                                        "text": "Call the Service Center",
                                        "value": "call"
                                    }
                                        ]
                        }
                        ]
                    }*/
      }
        
    };
    
    // call another lambda to initiate outbound call
    
 var requestForOutBoundCall = {
  "name": "Octank Call Center Toll Free ",
  "number": "+12222222222",
  "day": "Friday"
};


var lambda = new AWS.Lambda();

var responseForOutBoundCall = await lambda.invoke({
  FunctionName: 'arn:aws:lambda:us-east-1:414210492846:function:AdPromo-Call-Outbound',
  Payload: JSON.stringify(requestForOutBoundCall), // pass params,
  InvocationType: 'Event'
}, function(error, data) {
  if (error) {
    console.log("Outbound call failed...",JSON.stringify(error));
  }
  if(data.Payload){
          console.log("Outbound call success...");

  }
}).promise();

console.log("Called the Outbound Call Lambda");
console.log(responseForOutBoundCall);
    
    }
   
    
   
  }
    return response;
};
